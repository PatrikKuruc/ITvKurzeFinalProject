package shooter.Menu;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel0_Menu extends JPanel {

	/**
	 * Create the panel.
	 */
	public Panel0_Menu() {
		setBounds(300, 50, 350, 400);
		setBackground(Color.RED);
		setLayout(null);
		setVisible(false);
	}

}
