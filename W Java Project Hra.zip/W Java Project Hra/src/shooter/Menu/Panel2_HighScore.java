package shooter.Menu;

import java.awt.Color;

import javax.swing.JPanel;

public class Panel2_HighScore extends JPanel {

	/**
	 * Create the panel.
	 */
	public Panel2_HighScore() {
		setBounds(300, 50, 350, 400);
		setBackground(Color.LIGHT_GRAY);
		setLayout(null);
		setVisible(false);
	}

}
