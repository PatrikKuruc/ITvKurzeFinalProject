package shooter.mapGen;

import javax.swing.JPanel;

public class panelMapy extends JPanel {

	/**
	 * Create the panel.
	 */
	public panelMapy() {
		setBounds(250, 10, 500, 70);
	}

}
